class TestAutomaticParkingSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_parked_module_success(self):
        # Create an instance of the AutomaticParking class
        parking_system = AutomaticParking(parking_button=True)


        # Call the ParkedModule method
        parking_system.ParkedModule(parking_button=True)


        # Assert that the method prints the correct message
        self.assertEqual(self.out.getvalue().strip(), "Car is parked successfully")


    def test_parked_module_failure(self):
        # Create an instance of the AutomaticParking class
        parking_system = AutomaticParking(parking_button=False)


        # Call the ParkedModule method
        parking_system.ParkedModule(parking_button=False)


        # Assert that the method prints the correct message
        self.assertEqual(self.out.getvalue().strip(), "Car could not park successfully")
