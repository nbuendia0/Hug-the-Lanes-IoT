class TestCruiseControlSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_vcs_cruise_control_active(self):
        # Create an instance of the CruiseControl class
        cruise_control_system = CruiseControl()


        # Set the cruise_control_active to True to simulate cruise control active state
        cruise_control_system.cruise_control_active = True


        # Call the VCS method with propulsion and braking True to simulate cruise control mode
        cruise_control_system.VCS(propulsion=True, braking=True)


        # Assert that the method prints the correct message
        self.assertEqual(self.out.getvalue().strip(), "Vehicle is in cruise control mode")


    def test_vcs_cruise_control_inactive(self):
        # Create an instance of the CruiseControl class
        cruise_control_system = CruiseControl()


        # Call the VCS method without cruise control active to simulate not in cruise control mode
        cruise_control_system.VCS(propulsion=True, braking=True)


        # Assert that the method prints the correct message and sets cruise_control_active to False
        expected_output = "Vehicle is not in cruise control mode"
        self.assertEqual(self.out.getvalue().strip(), expected_output)
        self.assertFalse(cruise_control_system.cruise_control_active)