class TestAccelerationLaunchSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_planning_optimal_conditions(self):
        # Create an instance of the AccelerationLaunch class
        acceleration_system = AccelerationLaunch()


        # Mock SensorFusion method to return optimal conditions for launch
        acceleration_system.SensorFusion = lambda: [0, 1, 0, 0, 1]


        # Call the Planning method
        acceleration_system.Planning()


        # Assert that the method prints the correct message
        self.assertEqual(self.out.getvalue().strip(), "Road conditions and engine performance are optimal for launch.")


    def test_planning_non_optimal_conditions(self):
        # Create an instance of the AccelerationLaunch class
        acceleration_system = AccelerationLaunch()


        # Mock SensorFusion method to return non-optimal conditions for launch
        acceleration_system.SensorFusion = lambda: [1, 1, 0, 0, 1]


        # Call the Planning method
        acceleration_system.Planning()


        # Assert that the method prints the correct message
        self.assertEqual(self.out.getvalue().strip(), "Road conditions or engine performance are not optimal for launch.")
