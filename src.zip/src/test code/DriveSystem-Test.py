class TestDriveSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_start_drive(self):
        # Create an instance of the Drive class
        drive_system = Drive()


        # Set the battery_charge_level, gear, and systems_operational values to simulate readiness
        drive_system.battery_charge_level = 50
        drive_system.gear = "Drive"
        drive_system.systems_operational = True


        # Call the start_drive method
        result = drive_system.start_drive()


        # Assert that the method prints the correct message and returns True
        self.assertEqual(self.out.getvalue().strip(), "Vehicle is ready to drive.")
        self.assertTrue(result)
