import unittest
from io import StringIO
import sys


class TestIoTSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_car_ready_to_drive(self):
        # Create an instance of the IoT class
        iot_system = IoT()


        # Set the driver_has_key, car_is_on, and speedometer values to simulate readiness
        iot_system.driver_has_key = True
        iot_system.car_is_on = True
        iot_system.speedometer = 0


        # Call the ready_to_drive method
        result = iot_system.ready_to_drive()


        # Assert that the method prints the correct message and returns True
        self.assertEqual(self.out.getvalue().strip(), "The Car is ready to drive.")
        self.assertTrue(result)


if __name__ == '__main__':
    unittest.main()
