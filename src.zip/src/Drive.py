class Drive:
    # Constructor for the Drive class
    def __init__(self):
        # Initialize the state of the battery charge level, gear, and system's operational status
        self.battery_charge_level = 0
        self.gear = ""
        self.systems_operational = False


    # Method to check the preconditions for driving
    def check_preconditions(self, battery_charge_level, gear, systems_operational):
        # Update the state of the battery charge level, gear, and system's operational status
        self.battery_charge_level = battery_charge_level
        self.gear = gear
        self.systems_operational = systems_operational


        # Check if the battery charge level is above 0, the gear is set to 'Drive', and the systems are operational
        if self.battery_charge_level > 0 and self.gear == "Drive" and self.systems_operational:
            return True
        else:
            return False


    # Method to start driving
    def start_drive(self):
        # Check the preconditions for driving
        if self.check_preconditions(self.battery_charge_level, self.gear, self.systems_operational):
            # If the preconditions are met, print a message and return True
            print("Vehicle is ready to drive.")
            return True
        else:
            # If the preconditions are not met, print a message and return False
            print("Preconditions not met. Please ensure the battery charge level is above the minimum threshold, the gear is set to 'Drive', and all vehicle systems are operational.")
            return False


    # Method to end driving
    def end_drive(self, destination_reached, battery_charge_level):
        # Check if the destination has been reached and the battery charge level is above 0
        if destination_reached and battery_charge_level > 0:
            # If the postconditions are met, print a message and return True
            print("Vehicle has reached the destination without any critical performance issues. Battery charge level is above the minimum required for further operations.")
            return True
        else:
            # If the postconditions are not met, print a message and return False
            print("Postconditions not met. Please ensure the vehicle has reached the destination and the battery charge level is above the minimum required for further operations.")
            return False
