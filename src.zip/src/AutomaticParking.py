class AutomaticParking:
    def __init__(self, parking_button):
        self.parking_button = False


    # Activate automatic parking feature
    def AutomaticParkingSystem(self):
        self.parking_button = False
        self.motor_output = 10
        self.traction_control = 100


    # Verify car state
    def ParkedModule(self, parking_button):
        self.AutomaticParkingSystem(parking_button)
        if self.parking_button:
            print("Car is parked successfully")
        else:
            print("Car could not park successfully")


    # Detect parking spaces and obstacles
    def Cameras(self):
        return [0, 1, 0, 0, 1]
   
    # Find parking spaces to use
    def Planning(self):
        if 0 in self.Cameras():
            print("Parking space detected")
        else:
            print("No parking space detected")
   
    # Control vehicle movement for parking
    def VCS(self, motor_output, traction_control):
        self.AutomaticParkingSystem(motor_output, traction_control)
        if self.motor_output and self.traction_control:
            print("Vehicle is moving")
        else:
            print("Vehicle is not moving")
