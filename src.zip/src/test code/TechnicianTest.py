import unittest
import tkinter as tk
from unittest.mock import patch, MagicMock
import sqlite3


# Import the functions from your system_management.py file
from system_management import authenticate_technician, retrieve_logs, update_software, login # type: ignore


class TestSystemManagement(unittest.TestCase):


   def setUp(self):
       # Create a test database
       self.conn = sqlite3.connect(':memory:')
       self.c = self.conn.cursor()
       self.c.execute('''CREATE TABLE technicians
                         (username TEXT PRIMARY KEY, password TEXT)''')
       self.c.execute("INSERT INTO technicians VALUES ('admin', 'password123')")
       self.c.execute("INSERT INTO technicians VALUES ('tech1', 'securepass')")
       self.conn.commit()


   def tearDown(self):
       self.conn.close()


   def test_authenticate_technician(self):
       self.assertTrue(authenticate_technician('admin', 'password123'))
       self.assertTrue(authenticate_technician('tech1', 'securepass'))
       self.assertFalse(authenticate_technician('invaliduser', 'wrongpassword'))


   @patch('tkinter.filedialog.askopenfilename')
   def test_retrieve_logs(self, mock_askopenfilename):
       mock_askopenfilename.return_value = '/path/to/log.txt'
       with patch('tkinter.messagebox.showinfo') as mock_showinfo:
           retrieve_logs()
           mock_showinfo.assert_called_with('Log File', 'Selected log file: /path/to/log.txt')


   @patch('tkinter.messagebox.showinfo')
   def test_update_software(self, mock_showinfo):
       update_software()
       mock_showinfo.assert_called_with('Software Update', 'Software update initiated. Please wait...')


   @patch('tkinter.messagebox.showinfo')
   @patch('tkinter.messagebox.showerror')
   def test_login(self, mock_showerror, mock_showinfo):
       root = tk.Tk()
       logs_button = tk.Button(root)
       update_button = tk.Button(root)


       # Test with valid credentials
       login('admin', 'password123', logs_button, update_button)
       mock_showinfo.assert_called_with('Login', 'Login successful!')
       self.assertEqual(logs_button.cget('state'), 'normal')
       self.assertEqual(update_button.cget('state'), 'normal')


       # Test with invalid credentials
       mock_showinfo.reset_mock()
       login('invaliduser', 'wrongpassword', logs_button, update_button)
       mock_showerror.assert_called_with('Login', 'Invalid credentials. Please try again.')
       self.assertEqual(logs_button.cget('state'), 'disabled')
       self.assertEqual(update_button.cget('state'), 'disabled')


       root.destroy()


if __name__ == '__main__':
   unittest.main()
