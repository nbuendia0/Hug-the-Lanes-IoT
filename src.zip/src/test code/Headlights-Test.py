class TestHeadlightsSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_turn_on_headlights_success(self):
        # Create an instance of the Headlights class
        headlights_system = Headlights()


        # Set the ambient_light_level and headlights_setting to meet preconditions
        headlights_system.ambient_light_level = 2
        headlights_system.headlights_setting = "low"


        # Call the turn_on_headlights method
        result = headlights_system.turn_on_headlights()


        # Assert that the method prints the correct message and returns True
        self.assertEqual(self.out.getvalue().strip(), "Headlights are turned on and functioning properly, providing adequate illumination of the road ahead for the driver and other road users.")
        self.assertTrue(result)


    def test_turn_on_headlights_failure(self):
        # Create an instance of the Headlights class
        headlights_system = Headlights()


        # Set the ambient_light_level and headlights_setting to fail preconditions
        headlights_system.ambient_light_level = 5
        headlights_system.headlights_setting = "off"


        # Call the turn_on_headlights method
        result = headlights_system.turn_on_headlights()


        # Assert that the method prints the correct message and returns False
        self.assertEqual(self.out.getvalue().strip(), "Preconditions not met. Please ensure the ambient light level is below 3 or the headlights setting is set to 'low' or 'high'.")
        self.assertFalse(result)
