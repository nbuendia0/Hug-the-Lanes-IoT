class IoT:
    # Constructor for the IoT class
    def __init__(self):
        # Initialize the state of the driver's key, car's status, and speedometer
        self.driver_has_key = False
        self.car_is_on = False
        self.speedometer = 0


    # Method to check the preconditions for driving
    def check_preconditions(self, driver_has_key, car_is_on, speedometer):
        # Update the state of the driver's key, car's status, and speedometer
        self.driver_has_key = driver_has_key
        self.car_is_on = car_is_on
        self.speedometer = speedometer


        # Check if the driver has the key, the car is on, and the speedometer reads 0 mph
        if self.driver_has_key and self.car_is_on and self.speedometer == 0:
            return True
        else:
            return False


    # Method to initialize the systems for driving
    def initialize_systems(self):
        # Check the preconditions for driving
        if self.check_preconditions(self.driver_has_key, self.car_is_on, self.speedometer):
            # If the preconditions are met, print a message and return True
            print("All necessary systems are initialized and operational.")
            return True
        else:
            # If the preconditions are not met, print a message and return False
            print("Preconditions not met. Please ensure you have the key, the car is on, and the speedometer reads 0 mph.")
            return False


    # Method to check if the car is ready to drive
    def ready_to_drive(self):
        # Check if the systems are initialized for driving
        if self.initialize_systems():
            # If the systems are initialized, print a message and return True
            print("The Car is ready to drive.")
            return True
        else:
            # If the systems are not initialized, print a message and return False
            print("The Car is not ready to drive.")
            return False
