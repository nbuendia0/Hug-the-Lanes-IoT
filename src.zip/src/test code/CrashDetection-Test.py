class TestCrashDetectionSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_initiate_crash_detection_success(self):
        # Create an instance of the CrashDetection class
        crash_detection_system = CrashDetection()


        # Set the preconditions to True to simulate successful crash detection initiation
        crash_detection_system.impact_force = 6  # Greater than 5 g-force
        crash_detection_system.deceleration = 0.6  # Greater than 0.5 g
        crash_detection_system.time_interval = 0.1  # Less than 0.2 seconds


        # Call the initiate_crash_detection method
        result = crash_detection_system.initiate_crash_detection()


        # Assert that the method prints the correct messages and returns True
        expected_output = "Potential collision detected. Initiating automatic emergency braking and airbag deployment.\nAutomatic emergency braking engaged. Impact velocity reduced. Airbags deployed. Emergency services notified."
        self.assertEqual(self.out.getvalue().strip(), expected_output)
        self.assertTrue(result)


    def test_initiate_crash_detection_failure(self):
        # Create an instance of the CrashDetection class
        crash_detection_system = CrashDetection()


        # Call the initiate_crash_detection method without meeting preconditions to simulate failure
        result = crash_detection_system.initiate_crash_detection()


        # Assert that the method prints the correct message and returns False
        self.assertEqual(self.out.getvalue().strip(), "Preconditions not met. Please ensure the vehicle experiences an impact registering at least 5 g-force or a deceleration exceeding 0.5 g over 0.2 seconds.")
        self.assertFalse(result)
