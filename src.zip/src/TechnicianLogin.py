import sqlite3
from PyInquirer import prompt, Validator, ValidationError


class TechnicianLogin:
   def __init__(self, database_file):
       self.username = None
       self.password = None
       self.is_logged_in = False
       self.db_connection = sqlite3.connect(database_file)
       self.create_table()


   def create_table(self):
       cursor = self.db_connection.cursor()
       cursor.execute("""
           CREATE TABLE IF NOT EXISTS technicians (
               username TEXT PRIMARY KEY,
               password TEXT
           )
       """)
       self.db_connection.commit()


   def add_technician(self, username, password):
       cursor = self.db_connection.cursor()
       cursor.execute("INSERT OR REPLACE INTO technicians (username, password) VALUES (?, ?)", (username, password))
       self.db_connection.commit()


   def login_interface(self):
       while not self.is_logged_in:
           questions = [
               {
                   'type': 'input',
                   'name': 'username',
                   'message': 'Enter your username:',
                   'validate': UsernameValidator
               },
               {
                   'type': 'password',
                   'name': 'password',
                   'message': 'Enter your password:',
                   'validate': PasswordValidator
               }
           ]
           answers = prompt(questions)
           self.username = answers['username']
           self.password = answers['password']
           self.authenticate()


   def authenticate(self):
       cursor = self.db_connection.cursor()
       cursor.execute("SELECT * FROM technicians WHERE username=? AND password=?", (self.username, self.password))
       result = cursor.fetchone()


       if result:
           self.is_logged_in = True
           print("Login successful!")
           self.display_interface()
       else:
           print("Invalid username or password. Please try again.")


   def display_interface(self):
       while self.is_logged_in:
           questions = [
               {
                   'type': 'list',
                   'name': 'choice',
                   'message': 'Technician Interface',
                   'choices': [
                       'View System Updates',
                       'Perform Diagnostics',
                       'Log Out'
                   ]
               }
           ]
           answer = prompt(questions)['choice']


           if answer == 'View System Updates':
               self.view_system_updates()
           elif answer == 'Perform Diagnostics':
               self.perform_diagnostics()
           elif answer == 'Log Out':
               self.logout()
               break


   def view_system_updates(self):
       print("Displaying system updates...")
       # Call the necessary classes and methods to retrieve and display update information


   def perform_diagnostics(self):
       print("Performing diagnostics...")
       # Call the necessary classes and methods to run diagnostics


   def logout(self):
       self.is_logged_in = False
       print("Logged out successfully.")


class UsernameValidator(Validator):
   def validate(self, document):
       if len(document.text) < 4:
           raise ValidationError(
               message='Username must be at least 4 characters long',
               cursor_position=len(document.text))


class PasswordValidator(Validator):
   def validate(self, document):
       if len(document.text) < 8:
           raise ValidationError(
               message='Password must be at least 8 characters long',
               cursor_position=len(document.text))


# Example usage
technician_login = TechnicianLogin("technicians.db")


# Add some technicians to the database
technician_login.add_technician("admin", "password")
technician_login.add_technician("tech1", "securepassword")


technician_login.login_interface()