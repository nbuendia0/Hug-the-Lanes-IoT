class TestObstacleAvoidanceSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_vcs_obstacle_avoidance(self):
        # Create an instance of the ObstacleAvoidance class
        avoidance_system = ObstacleAvoidance()


        # Call the VCS method with all parameters True to simulate avoiding an obstacle
        avoidance_system.VCS(steering=True, throttle=True, brake=True)


        # Assert that the method prints the correct message
        self.assertEqual(self.out.getvalue().strip(), "Vehicle is avoiding obstacle")


    def test_vcs_no_obstacle_avoidance(self):
        # Create an instance of the ObstacleAvoidance class
        avoidance_system = ObstacleAvoidance()


        # Call the VCS method with all parameters False to simulate not avoiding an obstacle
        avoidance_system.VCS(steering=False, throttle=False, brake=False)


        # Assert that the method prints the correct message
        self.assertEqual(self.out.getvalue().strip(), "Vehicle is not avoiding obstacle")
