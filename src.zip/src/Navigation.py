class Navigation:
    def __init__(self):
        self.destination_inputted = False
        self.route_calculated = False
        self.gps_engaged = False


    # Method to check the preconditions for navigation
    def check_preconditions(self, destination_inputted, route_calculated, gps_engaged):
        self.destination_inputted = destination_inputted
        self.route_calculated = route_calculated
        self.gps_engaged = gps_engaged


        # Check if a destination has been inputted or a route has been calculated, and the GPS is engaged
        if (self.destination_inputted or self.route_calculated) and self.gps_engaged:
            return True
        else:
            return False


    # Method to initiate navigation
    def initiate_navigation(self):
        if self.check_preconditions(self.destination_inputted, self.route_calculated, self.gps_engaged):
            print("Navigation initiated. Following the planned route.")
            # Code for following the route would go here
            print("Route followed accurately. Driver guided to the destination with ease and precision.")
            return True
        else:
            print("Preconditions not met. Please ensure a destination is inputted or a route is calculated, and the GPS is engaged.")
            return False
