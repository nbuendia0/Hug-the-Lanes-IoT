class Headlights:
    def __init__(self):
        self.ambient_light_level = 0
        self.headlights_status = False
        self.headlights_setting = ""


    # Method to check the preconditions for turning on the headlights
    def check_preconditions(self, ambient_light_level, headlights_setting):
        self.ambient_light_level = ambient_light_level
        self.headlights_setting = headlights_setting


        # Check if the ambient light level is below 3 or the headlights setting is set to 'low' or 'high'
        if self.ambient_light_level < 3 or self.headlights_setting in ['low', 'high']:
            return True
        else:
            return False


    # Method to turn on the headlights
    def turn_on_headlights(self):
        if self.check_preconditions(self.ambient_light_level, self.headlights_setting):
            self.headlights_status = True
            print("Headlights are turned on and functioning properly, providing adequate illumination of the road ahead for the driver and other road users.")
            return True
        else:
            print("Preconditions not met. Please ensure the ambient light level is below 3 or the headlights setting is set to 'low' or 'high'.")
            return False