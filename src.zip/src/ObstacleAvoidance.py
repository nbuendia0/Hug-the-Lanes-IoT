class ObstacleAvoidance:
    def __init__(self):
        self.obstacle_data = []
        self.evasive_maneuver = 0


    # Detect obstacles
    # Analyze data for evasive maneuver
    def ObstacleAvoidanceSystem(self, obstacle_data, evasive_maneuver):
        self.obstacle_data = obstacle_data
        self.evasive_maneuver = evasive_maneuver


    # Receive obstacle data
    def SensorFusion(self, obstacle_data):
        self.obstacle_data = [0, 1, 0, 0, 0, 1, 1]
        return self.obstacle_data


    # Calculate evasive maneuver
    # 5 represents a level 5 evasive maneuver
    def Planning(self, evasive_maneuver):
        self.evasive_maneuver = 5
        return self.evasive_maneuver


    # Control steering, throttle, and brake
    def VCS(self, steering, throttle, brake):
        if steering and throttle and brake:
            print("Vehicle is avoiding obstacle")
        else:
            print("Vehicle is not avoiding obstacle")