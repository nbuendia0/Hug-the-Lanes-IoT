class TestNavigationSystem(unittest.TestCase):
    def setUp(self):
        # Redirect stdout for testing print outputs
        self.saved_stdout = sys.stdout
        self.out = StringIO()
        sys.stdout = self.out


    def tearDown(self):
        # Restore stdout
        sys.stdout = self.saved_stdout


    def test_initiate_navigation_success(self):
        # Create an instance of the Navigation class
        navigation_system = Navigation()


        # Set the preconditions to True to simulate successful navigation initiation
        navigation_system.destination_inputted = True
        navigation_system.route_calculated = True
        navigation_system.gps_engaged = True


        # Call the initiate_navigation method
        result = navigation_system.initiate_navigation()


        # Assert that the method prints the correct messages and returns True
        expected_output = "Navigation initiated. Following the planned route.\nRoute followed accurately. Driver guided to the destination with ease and precision."
        self.assertEqual(self.out.getvalue().strip(), expected_output)
        self.assertTrue(result)


    def test_initiate_navigation_failure(self):
        # Create an instance of the Navigation class
        navigation_system = Navigation()


        # Call the initiate_navigation method without meeting preconditions to simulate failure
        result = navigation_system.initiate_navigation()


        # Assert that the method prints the correct message and returns False
        self.assertEqual(self.out.getvalue().strip(), "Preconditions not met. Please ensure a destination is inputted or a route is calculated, and the GPS is engaged.")
        self.assertFalse(result)
