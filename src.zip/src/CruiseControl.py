class CruiseControl:
    def __init__(self):
        self.cruise_control_active = False
        self.speed_request = 0
        self.throttle_brake_settings = 0
        self.current_speed = 60
        self.speed_limit = 60


    # Activate and manage cruise control
    # Monitor vehicle conditions
    def CruiseControlSystem(self, cruise_control_active, speed_request):
        self.cruise_control_active = cruise_control_active
        self.speed_request = speed_request


    # Set the current speed as the speed request
    def SensorFusion(self, speed_request, current_speed):
        # If speed is less than 80, set speed request
        if self.current_speed < 80:
            self.speed_request = current_speed
            return speed_request
        else:
            print("Cannot enable cruise control at current speed")


    # Calculate throttle and brake settings
    def Planning(self, throttle_brake_settings, speed_limit):
        # If current speed is less than speed limit, set throttle
        if self.current_speed < self.speed_limit:
            self.throttle_brake_settings = 1
            return throttle_brake_settings
        # If current speed is greater than speed limit, set brake
        else:
            self.throttle_brake_settings = -1
            return throttle_brake_settings


    # Control propulsion and braking
    def VCS(self, propulsion, braking):
        if propulsion and braking:
            print("Vehicle is in cruise control mode")
        else:
            print("Vehicle is not in cruise control mode")
            self.cruise_control_active = False
